package com.example.heart_to_heart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import com.example.heart_to_heart.Adapters.ChatAdapter;
import com.example.heart_to_heart.Adapters.SMAdapter;
import com.example.heart_to_heart.Models.MessageModel;
import com.example.heart_to_heart.databinding.ActivitySmChatBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Date;

public class SM_Chat extends AppCompatActivity {
    ActivitySmChatBinding binding;
    FirebaseAuth auth;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySmChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().hide();

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        final String senderId = auth.getUid();
        String receiverId = getIntent().getStringExtra("userId");
        String name = getIntent().getStringExtra("name");
        String profilepicture = getIntent().getStringExtra("profilepicture");

        binding.profileImage.setImageURI(Uri.parse(profilepicture));
        Picasso.get().load(profilepicture).placeholder(R.drawable.profile).into(binding.profileImage);

        binding.backarrowsecretmessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SM_Chat.this, Secret_Message.class);
                startActivity(intent);
            }
        });

        binding.profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SM_Chat.this, View_ChatProfile.class);
                startActivity(intent);
            }
        });

        final ArrayList<MessageModel> messageModels = new ArrayList<>();

        final SMAdapter smAdapter = new SMAdapter(messageModels , this);
        binding.secretmessagerecyclerview.setAdapter(smAdapter);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        binding.secretmessagerecyclerview.setLayoutManager(layoutManager);

        final String sendersmRoom = senderId + receiverId;
        final String receiversmRoom = receiverId + senderId;

        database.getReference().child("Secret Message").child(sendersmRoom).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                messageModels.clear();
                for (DataSnapshot snapshot1 : snapshot.getChildren()){
                    MessageModel model = snapshot1.getValue(MessageModel.class);
                    model.setMessageId(snapshot1.getKey());
                    messageModels.add(model);
                }
                smAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        binding.send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mesaage = binding.message.getText().toString();
                final  MessageModel model = new MessageModel(senderId , mesaage);
                model.setTimestamp(new Date().getTime());
                binding.message.setText("");

                database.getReference().child("Secret Message").child(sendersmRoom).push().setValue(model).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        database.getReference().child("Secret Message").child(receiversmRoom).push().setValue(model).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {

                            }
                        });
                    }
                });

            }
        });
    }
}