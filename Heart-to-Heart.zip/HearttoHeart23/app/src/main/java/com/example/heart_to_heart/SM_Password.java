package com.example.heart_to_heart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.heart_to_heart.Models.Users;
import com.example.heart_to_heart.databinding.ActivitySmPasswordBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class SM_Password extends AppCompatActivity {
    ActivitySmPasswordBinding binding;
    ProgressDialog progressDialog;
    private FirebaseAuth auth;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySmPasswordBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().hide();

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        progressDialog = new ProgressDialog(SM_Password.this);
        progressDialog.setTitle("Creating Secret Message");
        progressDialog.setMessage("We are creating your secret message");

        binding.save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!binding.smpassword.getText().toString().isEmpty()) {
                    Users user = new Users( binding.smpassword.getText().toString());
                    String id = user.getSmpassword();
                    database.getReference().child("Users").child(id).setValue(user);
                    Toast.makeText(SM_Password.this, "Password Created Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(SM_Password.this,Secret_Message.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(SM_Password.this,"Enter Credentials!!!",Toast.LENGTH_SHORT).show();
                }
            }
        });

        binding.createdpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SM_Password.this,Password_SM.class);
                startActivity(intent);
            }
        });
    }
}