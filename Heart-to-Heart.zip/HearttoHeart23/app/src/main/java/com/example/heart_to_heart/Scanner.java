package com.example.heart_to_heart;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.heart_to_heart.databinding.ActivityScannerBinding;

public class Scanner extends AppCompatActivity {
    ActivityScannerBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityScannerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().hide();
    }
}