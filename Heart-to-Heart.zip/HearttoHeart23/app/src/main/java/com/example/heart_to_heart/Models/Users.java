package com.example.heart_to_heart.Models;

public class Users {String profilepicture, name, phonenumber, email, password, smpassword, userId, about, lastmessage;

    public Users(String profilepicture, String name, String phonenumber, String email, String password,String smpassword, String userId, String about, String lastmessage) {
        this.profilepicture = profilepicture;
        this.name = name;
        this.phonenumber = phonenumber;
        this.email = email;
        this.password = password;
        this.smpassword = smpassword;
        this.userId = userId;
        this.about = about;
        this.lastmessage = lastmessage;
    }

    public Users(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
    }

    public Users(String smpassword) {
        this.smpassword = smpassword;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Users() {

    }

    public String getProfilepicture() {
        return profilepicture;
    }

    public void setProfilepicture(String profilepicture) {
        this.profilepicture = profilepicture;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSmpassword() {
        return smpassword;
    }

    public void setSmpassword(String smpassword) {
        this.smpassword = smpassword;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public String getLastmessage() {
        return lastmessage;
    }

    public void setLastmessage(String lastmessage) {
        this.lastmessage = lastmessage;
    }


}
