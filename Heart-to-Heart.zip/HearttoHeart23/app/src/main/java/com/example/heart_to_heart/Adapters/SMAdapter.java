package com.example.heart_to_heart.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.heart_to_heart.Models.MessageModel;
import com.example.heart_to_heart.R;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;

public class SMAdapter extends RecyclerView.Adapter {

    ArrayList<MessageModel> messageModels;
    Context context;

    int SENDER_VIEW_TYPE = 1;
    int RECEIVER_VIEW_TYPE = 2;

    public SMAdapter(ArrayList<MessageModel> messageModels, Context context) {
        this.messageModels = messageModels;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == SENDER_VIEW_TYPE)
        {
            View view = LayoutInflater.from(context).inflate(R.layout.sample_sender_sm , parent, false);
            return new SenderViewVolder(view);
        }
        else {
            View view = LayoutInflater.from(context).inflate(R.layout.sample_receiver_sm , parent, false);
            return new ReceiverViewVolder(view);
        }
    }


    @Override
    public int getItemViewType(int position) {
        if (messageModels.get(position).getuId().equals(FirebaseAuth.getInstance().getUid()))
        {
            return SENDER_VIEW_TYPE;
        }
        else {
            return RECEIVER_VIEW_TYPE;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        MessageModel messageModel = messageModels.get(position);
        if (holder.getClass() == SenderViewVolder.class){
            ((SenderViewVolder)holder).sendersmMsg.setText(messageModel.getMessage());
        }
        else {
            ((ReceiverViewVolder)holder).receiversmMsg.setText(messageModel.getMessage());
        }
    }

    @Override
    public int getItemCount() {
        return messageModels.size();
    }

    public class ReceiverViewVolder extends RecyclerView.ViewHolder{
        TextView receiversmMsg , receiversmTime;

        public ReceiverViewVolder(@NonNull View itemView){
            super(itemView);
            receiversmMsg = itemView.findViewById(R.id.receiversmtext);
            receiversmTime = itemView.findViewById(R.id.receiversmtime);
        }
    }

    public class SenderViewVolder extends RecyclerView.ViewHolder{
        TextView sendersmMsg , sendersmTime;

        public SenderViewVolder(@NonNull View itemView){
            super(itemView);
            sendersmMsg = itemView.findViewById(R.id.sendersmtext);
            sendersmTime = itemView.findViewById(R.id.sendersmtime);
        }
    }
}

