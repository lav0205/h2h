package com.example.heart_to_heart;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.heart_to_heart.databinding.ActivityInviteAfriendBinding;

public class Invite_a_friend extends AppCompatActivity {
    ActivityInviteAfriendBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityInviteAfriendBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().hide();

        binding.backarrowinvitefriend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Invite_a_friend.this, Settings.class);
                startActivity(intent);
            }
        });
    }
}